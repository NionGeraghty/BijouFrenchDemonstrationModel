-- MySQL dump 10.13  Distrib 8.0.35, for Linux (x86_64)
--
-- Host: 127.0.0.1    Database: bijoufrench
-- ------------------------------------------------------
-- Server version	8.0.35-0ubuntu0.23.04.1

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `action_events`
--

DROP TABLE IF EXISTS `action_events`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `action_events` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `batch_id` char(36) COLLATE utf8mb4_unicode_ci NOT NULL,
  `user_id` bigint unsigned NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `actionable_type` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `actionable_id` bigint unsigned NOT NULL,
  `target_type` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `target_id` bigint unsigned NOT NULL,
  `model_type` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `model_id` bigint unsigned DEFAULT NULL,
  `fields` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `status` varchar(25) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'running',
  `exception` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `original` mediumtext COLLATE utf8mb4_unicode_ci,
  `changes` mediumtext COLLATE utf8mb4_unicode_ci,
  PRIMARY KEY (`id`),
  KEY `action_events_actionable_type_actionable_id_index` (`actionable_type`,`actionable_id`),
  KEY `action_events_target_type_target_id_index` (`target_type`,`target_id`),
  KEY `action_events_batch_id_model_type_model_id_index` (`batch_id`,`model_type`,`model_id`),
  KEY `action_events_user_id_index` (`user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `action_events`
--

LOCK TABLES `action_events` WRITE;
/*!40000 ALTER TABLE `action_events` DISABLE KEYS */;
INSERT INTO `action_events` VALUES (1,'9b8b8526-8f37-4856-9857-0a3364d13ab6',1,'Create','App\\Models\\Course',5,'App\\Models\\Course',5,'App\\Models\\Course',5,'','finished','','2024-03-12 08:22:46','2024-03-12 08:22:46',NULL,'{\"title\":\"Test Course\",\"access_code\":\"pomme\",\"updated_at\":\"2024-03-12T09:22:46.000000Z\",\"created_at\":\"2024-03-12T09:22:46.000000Z\",\"id\":5}'),(2,'9b8b868e-9b23-4126-8a68-1a1785f9360d',1,'Create','App\\Models\\Activity',41,'App\\Models\\Activity',41,'App\\Models\\Activity',41,'','finished','','2024-03-12 08:26:42','2024-03-12 08:26:42',NULL,'{\"title\":\"Test ac\",\"order_column\":\"41\",\"worksheet\":\"files\\/g4K67zEVC4RD3DsAoSq4G7Dy8GdHosFfQgy9jPQK.csv\",\"course_id\":5,\"updated_at\":\"2024-03-12T09:26:42.000000Z\",\"created_at\":\"2024-03-12T09:26:42.000000Z\",\"id\":41}');
/*!40000 ALTER TABLE `action_events` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `activities`
--

DROP TABLE IF EXISTS `activities`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `activities` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `order_column` int NOT NULL,
  `worksheet` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `answers` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `course_id` bigint unsigned DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `activities_course_id_foreign` (`course_id`),
  CONSTRAINT `activities_course_id_foreign` FOREIGN KEY (`course_id`) REFERENCES `courses` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=42 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `activities`
--

LOCK TABLES `activities` WRITE;
/*!40000 ALTER TABLE `activities` DISABLE KEYS */;
INSERT INTO `activities` VALUES (1,'Greetings',1,'Activity Sheet 1 - Greetings.docx','Activity Sheet 1 - Greetings_Answers.docx','2023-08-31 05:17:24','2023-08-31 05:43:44',1),(2,'Comment ça va',2,'Activity Sheet 2 - Comment ça va.docx','Activity Sheet 2 - Comment ça va_Answers.docx','2023-08-31 05:17:38','2023-09-02 06:49:06',1),(3,'Family',3,'Activity Sheet 3_Family.docx','Activity Sheet 3 -Family_Answers.docx','2023-08-31 05:17:58','2023-09-02 06:49:58',1),(4,'What is Their Name',4,'Activity Sheet 4 - What Is Their Name.docx','Activity Sheet 4 - What Is Their Name_Answers.docx','2023-08-31 05:18:26','2023-09-02 06:50:04',1),(5,'Family Song',5,'Activity Sheet 5_Family Song.docx','Activity Sheet 5-Family Song_Answers.docx','2023-08-31 05:18:43','2023-09-02 06:50:15',1),(6,'What Are They Like',6,'Activity Sheet 6_What Are They Like.docx','Activity Sheet 6 - What Are They Like_Answers.docx','2023-08-31 05:18:52','2023-09-02 06:50:20',1),(7,'Let It Snow',7,'Activity Sheet 7_Let It Snow.docx','Activity Sheet 7_Let It Snow_Answers.docx','2023-08-31 05:19:03','2023-09-02 06:50:28',1),(8,'Christmas Baubles',8,'Activity Sheet 8 - Christmas Baubles.docx','Activity Sheet 8- Christmas Baubles _Answers.docx','2023-08-31 05:19:12','2023-09-02 06:50:35',1),(9,'Decorating the Christmas Tree',9,'Activity Sheet 9 - Decorating The Christmas Tree.docx','Activity Sheet 9 - Decorating The Christmas Tree_Answers.docx','2023-08-31 05:19:26','2023-09-02 06:51:00',1),(10,'Yule Log and Quiz',10,'Activity Sheet 10 - Yule Log And Quiz.docx',NULL,'2023-08-31 05:19:43','2023-08-31 05:45:33',1),(11,'Christmas Challenge',11,'Activity Sheet 11_Christmas Challenges.docx','Activity Sheet 11_Christmas Challenges_Answers.docx','2023-08-31 05:19:52','2023-09-02 06:51:11',1),(12,'Colours',12,'Activity Sheet 1 - Colours.docx','Activity Sheet 1 - Colours_Answers.docx','2023-08-31 05:22:45','2023-09-10 18:03:11',2),(13,'Greetings',13,'Activity Sheet 2 - Greetings.docx','Activity Sheet 2 - Greetings_Answers.docx','2023-08-31 05:22:50','2023-09-02 06:51:44',2),(14,'Colours and Numbers',14,'Activity Sheet 3 - Colours And Numbers.docx','Activity Sheet 3 - Colours And Numbers _Answers.docx','2023-08-31 05:22:59','2023-09-02 06:52:12',2),(15,'All About Me',15,'Activity Sheet 4 - All About Me.docx','Activity Sheet 4 - All About Me_Answers.docx','2023-08-31 05:23:05','2023-09-02 06:52:25',2),(16,'Name and Age Song Challenges',16,'Activity Sheet 5 - Name And Age Song Challenges.docx','Activity Sheet 5 - Name And Age Song Challenges_Answers.docx','2023-08-31 05:23:17','2023-09-02 06:52:37',2),(17,'What I Like',17,'Activity Sheet 6 - What I Like.docx','Activity Sheet 6 - What I Like_Answers.docx','2023-08-31 05:23:25','2023-09-02 06:52:48',2),(18,'My Favourite Places',18,'Activity Sheet 7 - My Favourite Places.docx','Activity Sheet 7 - My Favourite Places_Answers.docx','2023-08-31 05:23:41','2023-09-02 06:52:58',2),(19,'Christmas Time',19,'Activity Sheet 8 - Christmas Time.docx','Activity Sheet 8 - Christmas Time_Answers.docx','2023-08-31 05:23:48','2023-09-02 06:53:09',2),(20,'All About Santa',20,'Activity Sheet 9 - All About Santa.docx','Activity Sheet 9 - All About Santa_Answers.docx','2023-08-31 05:23:53','2023-09-02 06:53:22',2),(21,'Chocolate Yule Log',21,'Activity Sheet 10 - Chocolate Yule Log.docx','Activity Sheet 10 - Chocolate Yule Log_Answers.docx','2023-08-31 05:24:06','2023-09-02 06:53:41',2),(22,'Christmas Fun and Challenges',22,'Activity Sheet 11 - Christmas Fun And Challenges.docx','Activity Sheet 11 - Christmas Fun And Challenges - Answers.docx','2023-08-31 05:24:17','2023-09-02 06:53:54',2),(23,'Sports and Activities',23,'Activity Sheet 1 - Sports and Activities.docx','Activity Sheet 1 -Sports and Activities_Answers.docx','2024-01-15 15:13:00','2024-01-15 15:14:26',3),(24,'Dinosaurs And Colours',24,'Activity Sheet 1 - Dinosaurs And Colours.docx','Activity Sheet 1 - Dinosaurs And Colours_Answers.docx','2024-01-15 15:27:42','2024-01-15 15:28:21',4),(25,'Dinosaur Song And Counting Challenge',25,'Activity Sheet 2 - Dinosaur Song And Counting Challenge.docx','Activity Sheet 2 - Dinosaur Song And Counting Challenge_Answers.docx','2024-01-18 15:27:49','2024-01-18 15:30:24',4),(26,'How Big Is The Dinosaur',26,'Activity Sheet 3 - How Big Is The Dinosaur.docx','Activity Sheet 3 - How Big Is The Dinosaur_Answers.docx','2024-01-18 15:28:42','2024-01-18 15:30:33',4),(27,'Dinosaur Book',27,'Activity Sheet 4 - Dinosaur Book.docx','Activity Sheet 4 - Dinosaur Book_Answers.docx','2024-01-18 15:28:50','2024-01-18 15:30:40',4),(28,'Football Fun',28,'Activity Sheet 2 - Football Fun.docx','Activity Sheet 2 - Football Fun_Answers.docx','2024-01-18 15:32:10','2024-01-18 15:33:32',3),(29,'My Favourite Sports',29,'Activity Sheet 3 - My Favourite Sports.docx','Activity Sheet 3 - My Favourite Sports_Answers.docx','2024-01-18 15:32:21','2024-01-18 15:33:39',3),(30,'Talking About The Weather',30,'Activity Sheet 4 - Talking About The Weather.docx','Activity Sheet 4 - Talking About The Weather_Answers.docx','2024-01-18 15:32:29','2024-01-18 15:33:48',3),(31,'Favourite Weather',31,'Activity Sheet 5 - Favourite Weather.docx','Activity Sheet 5 - Favourite Weather_Answers.docx','2024-01-23 10:51:58','2024-01-23 10:53:53',3),(32,'Easter Egg Hunt',32,'Activity Sheet 6 - Easter Egg Hunt.docx','Activity Sheet 6 - Easter Egg Hunt_Answers.docx','2024-01-23 10:52:08','2024-01-23 10:54:00',3),(33,'Easter Song',33,'Activity Sheet 7- Easter Song.docx','Activity Sheet 7- Easter Song_Answers.docx','2024-01-23 10:52:17','2024-01-23 11:02:38',3),(34,'Quiz And Treat',34,'Activity Sheet 8- Quiz And Treat.docx',NULL,'2024-01-23 10:52:25','2024-01-23 10:53:33',3),(35,'Easter Fun And Challenges',35,'Activity Sheet 9 - Easter Fun And Challenges.docx','Activity Sheet 9 - Easter Fun And Challenges_Answers.docx','2024-01-23 10:52:36','2024-01-23 11:03:17',3),(36,'Number Challenges',36,'Activity Sheet 5- Number Challenges.docx','Activity Sheet 5- Number Challenges_Answers.docx','2024-01-23 10:57:20','2024-01-23 10:59:21',4),(37,'Easter',37,'Activity Sheet 6 - Easter.docx','Activity Sheet 6 - Easter_Answers.docx','2024-01-23 10:57:31','2024-01-23 11:04:19',4),(38,'Masculine And Feminine Nouns',38,'Activity Sheet 7- Masculine And Feminine Nouns.docx','Activity Sheet 7- Masculine And Feminine Nouns_Answers.docx','2024-01-23 10:57:39','2024-01-23 11:04:38',4),(39,'Quiz And Treat',39,'Activity Sheet 8- Quiz And Treat.docx',NULL,'2024-01-23 10:57:47','2024-01-23 11:05:58',4),(40,'Easter Fun And Challenges',40,'Activity Sheet 9 - Easter Fun And Challenges.docx','Activity Sheet 9 - Easter Fun And Challenges_Answers.docx','2024-01-23 10:57:56','2024-01-23 11:05:48',4),(41,'Test ac',41,'files/g4K67zEVC4RD3DsAoSq4G7Dy8GdHosFfQgy9jPQK.csv',NULL,'2024-03-12 08:26:42','2024-03-12 08:26:42',5);
/*!40000 ALTER TABLE `activities` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `articles`
--

DROP TABLE IF EXISTS `articles`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `articles` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `text` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `slug` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `articles`
--

LOCK TABLES `articles` WRITE;
/*!40000 ALTER TABLE `articles` DISABLE KEYS */;
INSERT INTO `articles` VALUES (2,'About Sue','<h2>My Story</h2>\n<p>Bonjour! My name is Sue Backley, and I run <strong>Bijou French</strong>.</p>\n<p>I have always loved France and the French language. As a child I spent many happy holidays in France with my family, and we especially enjoyed our trips to Bordeaux to stay with friends. After studying French with German at university, I moved to Nancy in north-eastern France, where I spent 4 years teaching English to university students. I then lived in Paris for 3 years, where I continued to teach English at the Franco-British Chamber of Commerce. I loved my time in France, absorbing the culture and the language, and I continue to enjoy regular holidays there with my family. </p>\n<p>My professional life has been devoted to teaching. Since moving back to England and doing my teacher training, I have taught French and German in secondary schools and French at primary level. Teaching primary school pupils made me realise how well children respond to a language at a young age. I also witnessed first-hand how my own son (now 20 years old!) absorbed French naturally and with a great deal of enthusiasm and enjoyment when he was a child. With this in mind, I set up a French club for children called <strong>Les Petits Dauphins</strong> in January 2007. Since\nthen, I have taught countless children of primary age, in lunchtime and after-school clubs in Abingdon. I have loved every second of it!</p>\n<p>When Covid-19 struck in March 2020, I had no idea that I would be unable to return to work for over 18 months. Once the reality began to sink in, I decided to try to put the time to the best possible use and to produce something positive out of a difficult situation. And so, I am very happy to introduce you to Bijou French, my brand-new French course for primary children. So, what is new? As well as attending weekly face-to-face French classes at school, the children will have access to several new resources on my brand-new Bijou French website (see <a href=\"/about-bijou-french\">About Bijou French</a> for more information). I believe that, by offering this extra material to supplement the classes, I can offer a complete language learning experience, as well as making it easier for parents to get involved with their child’s learning, if they wish to do so.</p>\n<p>I am really excited to embark on this fresh adventure: I love finding new ways to share my passion for France and the French language, and I very much hope your child will enjoy learning French with Bijou French.</p>\n<p>À bientôt.</p>\n<p>Sue</p>\n<p>October 2022</p>','about-sue','2023-09-09 10:26:28','2023-09-09 10:26:28'),(6,'About Bijou French','<p><strong>The course</strong></p>\n<p>Bijou French is a fun, dynamic French course for primary school children, created by a qualified teacher with many years&rsquo; experience teaching children in this age range. The course is split into 3 levels: Mini Bijou for children in years 1-2, Petit Bijou for children in years 3-4 and Top Bijou for children in years 5-6. The Mini Bijou and Petit Bijou children will attend weekly breakfast or lunchtime clubs at school, on a day to be arranged with the school. The Top Bijou children will attend clubs run during the school holidays.</p>\n<p>As well as face-to-face lessons, the children will have the chance to consolidate and extend their learning using the following resources available on the website:</p>\n<ul>\n<li>\n<p>Downloadable activity sheets</p>\n</li>\n<li>\n<p>Song lyrics and audio versions of the songs</p>\n</li>\n<li>\n<p>Extra challenges and tips for further practice</p>\n</li>\n</ul>\n<p>The activity sheets allow the children to practise the language learned in the lessons and to explore some basic grammar points, as well as building in some reading and writing skills. Songs are a great way of learning a foreign language, and the children will be able to listen to our songs at home via the website and study the lyrics if they wish to. Extra challenges and tips are for those who wish to take their learning a little further.</p>\n<p><strong>The lessons</strong></p>\n<p>The lessons are packed with entertaining activities, such as games (including the ever-popular hide and seek and magic bag), stories, songs &amp; rhymes, and much more. Bijou the puppy will bring a smile to our faces as she joins us for some of the activities. Where possible, we will do a practical activity to complete a topic, for example role plays and food tasting. This helps to bring the topic to life, as well as hopefully being very enjoyable. The spirit of the lessons is light-hearted and the emphasis very much on fun &ndash; in my experience children learn best when they are having fun!</p>\n<p>The lessons cover a range of engaging topics, such as holidays, food &amp; drink, and hobbies, carefully selected to appeal to a range of interests and also to lay the foundations for language learning at secondary school. We also learn sub-topics, such as colours, numbers, and weather, which are built into the lessons each week. Individual and team challenges keep motivation levels high, and the children&rsquo;s efforts are rewarded with special French stickers and the occasional small prize for exceptional effort or achievement.</p>\n<p><strong>Pricing</strong></p>\n<p>Mini Bijou &amp; Petit Bijou lunchtime club: &pound;5.00 per session (payable termly in advance)</p>\n<p>Mini and Petit Bijou breakfast club (fees payable termly in advance):</p>\n<ul>\n<li>\n<p>&pound;5.50 per session (to include food and drink for breakfast)</p>\n</li>\n<li>\n<p>&pound;5.00 per session (food and drink not included)</p>\n</li>\n</ul>\n<p>Top Bijou holiday club: &pound;85 per course (three classes, each lasting 2.5 hours, to include drinks and snacks).</p>\n<p><strong>GCSE tuition</strong></p>\n<p>Bijou French also offers one-to-one GCSE French tuition. I have several years&rsquo; experience tutoring pupils in Year 10 and Year 11. I really enjoy helping pupils prepare for the GSCE French exam, giving them a confidence boost and helping them to fulfil their potential. In the GCSE tuition classes, I will support your child&rsquo;s learning by:</p>\n<ul>\n<li>\n<p>giving tailored help with all 4 language skills assessed in the GCSE French exam (reading, writing, listening, speaking).</p>\n</li>\n<li>\n<p>working with them to identify areas of the language where improvement may be needed and focussing on these areas.</p>\n</li>\n<li>\n<p>identifying and polishing their strengths in the French language, ensuring they make good use of these, especially in the papers where they have a little more control over the language they use (writing and speaking).</p>\n</li>\n<li>\n<p>in the months leading up to the GCSEs, providing guidance and support with exam preparation for GCSE French (effective revision and time management, etc) and exam technique (timing, familiarity with exam papers, breaking down difficult questions, gaining bonus points in writing and speaking, etc).</p>\n</li>\n</ul>\n<p>The GCSE tuition classes take place on a weekly basis, in my home in Abingdon. As a member of Bijou French, your child will also have access to the GCSE section of the Bijou French website (currently being developed). Here they will find tips for learning and revising French, and activity sheets to help practise key language points.</p>\n<p>Please email me for further information or to book your free 30 minute consultation: <u><a href=\"mailto:susannahbackley@gmail.com\">susannahbackley@gmail.com</a></u></p>\n<p>A bient&ocirc;t,</p>\n<p>Sue</p>','about-bijou-french','2023-09-10 07:56:51','2023-09-10 07:56:51'),(8,'Petit Bijou','<p><span><strong>Petit Bijou Language Summary: January to April 2024 (9 weeks)</strong></span></p>\n<p><span style=\"color: rgb(68, 114, 196);\"><em>This is a guide only: plenty of other language will be used during the lessons, and in the songs, the activity sheets, and the suggestions for further learning.</em></span></p>\n<p><br>&nbsp;</p>\n<p><span style=\"color: rgb(68, 114, 196);\"><span><strong>Greetings &amp; how we are feeling&nbsp;</strong></span></span><span style=\"color: rgb(0, 0, 0);\"><em>(review and develop from last term}</em></span></p>\n<p><span><strong>Bonjour</strong></span><span>&nbsp;(hello)&nbsp;</span><span><strong>Salut</strong></span><span>&nbsp;(hi)&nbsp;</span><span><strong>Au revoir</strong></span><span>&nbsp;(goodbye)&nbsp;</span><span><strong>&Agrave;</strong></span><span><strong>&nbsp;bient</strong></span><span><strong>&ocirc;</strong></span><span><strong>t</strong></span><span><span lang=\"fr-FR\">&nbsp;(see you soon)</span></span></p>\n<p><span><strong>Comment&nbsp;</strong></span><span><strong>&ccedil;</strong></span><span><strong>a va</strong></span><span>?/</span><span>&Ccedil;</span><span>a va (how are you/how&rsquo;s it going)</span></p>\n<p><span><strong>&Ccedil;</strong></span><span><strong>a va/</strong></span><span><strong>&Ccedil;</strong></span><span><strong>a va bien</strong></span><span>&nbsp;(I&rsquo;m okay/fine)&nbsp;</span><span><strong>Tr</strong></span><span><strong>&egrave;</strong></span><span><strong>s bien merci</strong></span><span><span lang=\"fr-FR\">&nbsp;(very well thanks)</span></span></p>\n<p><span><strong>&Ccedil;</strong></span><span><strong>a va mal</strong></span><span>&nbsp;(not good)&nbsp;</span><span><strong>Je suis fatigu</strong></span><span><strong>&eacute;</strong></span><span><strong>/fatigu</strong></span><span><strong>&eacute;</strong></span><span><strong>e</strong></span><span>&nbsp;(I&rsquo;m tired)&nbsp;</span><span><strong>Et toi/vous</strong></span><span><span lang=\"fr-FR\">&nbsp;(how about you?)</span></span></p>\n<p><br>&nbsp;</p>\n<p><span style=\"color: rgb(68, 114, 196);\"><strong>Topic 1: Sports and activities</strong></span></p>\n<p><em>We will learn to talk about sports and activities, with the focus being on the verb &ldquo;</em><strong>jouer&rdquo;</strong><em>&nbsp;(to play)</em></p>\n<p><span><strong>Tu joues au foot/tennis/cricket?&nbsp;</strong></span><span>(Do you play football/tennis/cricket?)</span></p>\n<p><span><strong>Je joue au foot</strong></span><span>&nbsp;(I play football)&nbsp;</span><span><strong>Je joue au tennis</strong></span><span><span lang=\"fr-FR\">&nbsp;(I play tennis)</span></span></p>\n<p><span><strong>Je joue au cricket</strong></span><span>&nbsp;(I play cricket)&nbsp;</span><span><strong>je joue avec mes amis</strong></span><span>&nbsp;(I play with my friends)&nbsp;</span></p>\n<p><span style=\"color: rgb(0, 0, 0);\"><em>We will add other examples in class and in the activity sheets</em></span></p>\n<p><br>&nbsp;</p>\n<p><span style=\"color: rgb(68, 114, 196);\"><strong>Topic 2: What&rsquo;s the weather like?</strong></span></p>\n<p><span><strong>Quel temps fait-il?</strong></span><span>&nbsp;(What&rsquo;s the weather like?)</span></p>\n<p><span><strong>Il fait beau&nbsp;</strong></span><span>(It&rsquo;s nice weather)&nbsp;</span><span><strong>Il pleut</strong></span><span>&nbsp;(it&rsquo;s raining)&nbsp;</span><span><strong>&nbsp;il fait froid&nbsp;</strong></span><span>(it&rsquo;s cold)&nbsp;</span></p>\n<p><span><strong>il y a du vent&nbsp;</strong></span><span>( it&rsquo;s windy)&nbsp;</span><span><strong>il neige</strong></span><span><span lang=\"fr-FR\">&nbsp;(it&rsquo;s snowing)</span></span></p>\n<p><br></p>\n<p><span style=\"color: rgb(68, 114, 196);\"><span lang=\"fr-FR\"><strong>Topic 3: Happy Easter</strong></span></span></p>\n<p><span><strong>une chasse aux oeufs de p</strong></span><span><strong>&acirc;</strong></span><span><strong>ques&nbsp;</strong></span><span><span lang=\"fr-FR\">(an Easter egg hunt)</span></span></p>\n<p><span><strong>les cloches</strong></span><span>&nbsp;(the bells)&nbsp;</span><span><strong>le lapin</strong></span><span>&nbsp;(the rabbit)&nbsp;</span><span><strong>le panier</strong></span><span>&nbsp;(the basket)</span></p>\n<p><span><strong>cacher</strong></span><span>&nbsp;(to hide)&nbsp;</span><span><strong>chercher</strong></span><span>&nbsp;(to look for)&nbsp;</span><span><strong>trouver</strong></span><span>&nbsp;(to find)&nbsp;</span><span><strong>manger</strong></span><span>&nbsp;(to eat)</span></p>\n<p><span><strong>Je voudrais un oeuf en chocolat s&rsquo;il vous pla</strong></span><span><strong>&icirc;</strong></span><span><strong>t =&nbsp;</strong></span><span>I&rsquo;d like</span><span><strong>&nbsp;</strong></span><span><span lang=\"fr-FR\">a chocolate egg please</span></span></p>\n<p><span><strong>Joyeuses P</strong></span><span><strong>&acirc;</strong></span><span><strong>ques</strong></span><span>&nbsp;(Happy Easter)</span></p>\n<p><br>&nbsp;</p>\n<p><span><strong>Basics</strong></span></p>\n<p><span>Colours and numbers&nbsp;</span></p>\n<p><br>&nbsp;</p>\n<p><span><strong>Songs</strong></span><span>&nbsp;</span></p>\n<p><span>Bonjour Bonjour comment&nbsp;</span><span>&ccedil;</span><span><span lang=\"fr-FR\">a va?</span></span></p>\n<p><span><span lang=\"fr-FR\">Je joue au foot</span></span></p>\n<p><span><span lang=\"fr-FR\">Petit Escargot</span></span></p>\n<p><span>P</span><span>&acirc;</span><span>ques est arriv</span><span>&eacute;</span><span><span lang=\"fr-FR\"></span></span></p>','petit-bijou','2024-01-15 15:06:08','2024-01-15 15:06:08'),(9,'Mini Bijou','<p><span size=\"4\"><strong>Mini Bijou Language Summary: January to April 2024 (9 weeks)</strong></span></p>\n<p><span style=\"color: rgb(0, 0, 0);\"><em>This is a guide only: plenty of other language will be used during the lessons, and in the songs, the activity sheets, and the suggestions for further learning.</em></span></p>\n<p><br>&nbsp;</p>\n<p><span style=\"color: rgb(68, 114, 196);\"><span><strong>Greetings &amp; how we are feeling&nbsp;</strong></span></span><span style=\"color: rgb(0, 112, 192);\"><em>(review from last term)</em></span></p>\n<p><span style=\"color: rgb(0, 0, 0);\"><span><span lang=\"fr-FR\"><strong>Bonjour</strong></span></span></span><span style=\"color: rgb(0, 0, 0);\"><span><span lang=\"fr-FR\">&nbsp;</span></span></span><span>(hello)&nbsp;</span><span><strong>Salut</strong></span><span>&nbsp;(hi)&nbsp;</span><span><strong>Au revoir</strong></span><span>&nbsp;(goodbye)&nbsp;</span><span><strong>A bient</strong></span><span><strong>&ocirc;</strong></span><span><strong>t</strong></span><span><span lang=\"fr-FR\">&nbsp;(see you soon)</span></span></p>\n<p><span><strong>Comment&nbsp;</strong></span><span><strong>&ccedil;</strong></span><span><strong>a va?/</strong></span><span><strong>&Ccedil;</strong></span><span><strong>a va</strong></span><span>?&nbsp;</span><span>(how are you/how&rsquo;s it going?)</span></p>\n<p><span><strong>&Ccedil;</strong></span><span><strong>a va/</strong></span><span><strong>&Ccedil;</strong></span><span><strong>a va bien</strong></span><span>&nbsp;(I&rsquo;m okay/fine)&nbsp;</span><span><strong>Tr</strong></span><span><strong>&egrave;</strong></span><span><strong>s bien merci</strong></span><span><span lang=\"fr-FR\">&nbsp;(very well thanks)</span></span></p>\n<p><span><strong>Je suis fatigu</strong></span><span><strong>&eacute;</strong></span><span><strong>/fatigu</strong></span><span><strong>&eacute;</strong></span><span><strong>e</strong></span> <span>(I&rsquo;m tired)&nbsp;</span><span><strong>&Ccedil;</strong></span><span><strong>a va mal</strong></span><span><span lang=\"fr-FR\">&nbsp;(Not good)</span></span></p>\n<p><br>&nbsp;</p>\n<p><span style=\"color: rgb(68, 114, 196);\"><span lang=\"fr-FR\"><strong>Topic 1: Dinosaurs - descriptions</strong></span></span></p>\n<p><span><strong>Le dinosaure est&hellip;&nbsp;</strong></span><span>(the dinosaur is&hellip;)&nbsp;</span></p>\n<p><span><strong>petit</strong></span><span>&nbsp;(small)&nbsp;</span><span><strong>grand</strong></span><span>&nbsp;(big)&nbsp;</span><span><strong>&eacute;</strong></span><span><strong>norme</strong></span><span>&nbsp;(enormous)&nbsp;</span><span><strong>gentil</strong></span><span>&nbsp;(kind)&nbsp;</span><span><strong>f</strong></span><span><strong>&eacute;</strong></span><span><strong>roce</strong></span><span>&nbsp;(fierce)</span></p>\n<p><span><strong>vert</strong></span><span>&nbsp;(green)&nbsp;</span><span><strong>bleu</strong></span><span>&nbsp;(blue)&nbsp;</span><span><strong>jaune</strong></span><span>&nbsp;(yellow)&nbsp;</span><span><strong>blanc</strong></span><span>&nbsp;(white)&nbsp;</span><span><strong>rouge</strong></span><span>&nbsp;(red), etc</span></p>\n<p><em>We will also be meeting some fruit and veg vocabulary in our book about a special dinosaur!&nbsp;</em></p>\n<p><br>&nbsp;</p>\n<p><span style=\"color: rgb(68, 114, 196);\"><span><span lang=\"fr-FR\"><strong>Topic 2: Easter&nbsp;</strong></span></span></span></p>\n<ol type=\"a\">\n    <li>\n        <p><span style=\"color: rgb(68, 114, 196);\"><span><strong>Nouns&nbsp;: masculine or feminine</strong></span></span><em>&nbsp;</em></p>\n    </li>\n</ol>\n<p><em>We will be learning about masculine feminine nouns in French, using some Easter vocabulary</em></p>\n<p><span><strong>un poussin&nbsp;</strong></span><span>(a chick)</span><span><strong>&nbsp;un lapin&nbsp;</strong></span><span>(a rabbit)&nbsp;</span><span><strong>un oeuf de P</strong></span><span><strong>&acirc;</strong></span><span><strong>ques</strong></span><span>&nbsp;(an Easter egg)&nbsp;</span></p>\n<p><span><strong>un panier</strong></span><span>&nbsp;(a basket)&nbsp;</span><span><strong>un jardin</strong></span><span>&nbsp;(a garden)&nbsp;</span><span><strong>une&nbsp;</strong></span><span><strong>&eacute;</strong></span><span><strong>glise</strong></span><span>&nbsp;(a church)&nbsp;</span></p>\n<p><span><strong>une fleur</strong></span><span>&nbsp;(a flower)&nbsp;</span><span><strong>une f</strong></span><span><strong>&ecirc;</strong></span><span><strong>te</strong></span><span>&nbsp;(a celebration)&nbsp;</span><span><strong>une carte</strong></span><span><span lang=\"fr-FR\">&nbsp;(a card)</span></span></p>\n<p><br>&nbsp;</p>\n<ol type=\"a\" start=\"2\">\n    <li>\n        <p><span style=\"color: rgb(68, 114, 196);\"><span lang=\"fr-FR\"><strong>Easter fun</strong></span></span></p>\n    </li>\n</ol>\n<p><span><strong>J&rsquo;ai trouv</strong></span><span><strong>&eacute;</strong></span><span><strong>&nbsp;un &oelig;uf en chocolat&nbsp;</strong></span><span><span lang=\"fr-FR\">(I&rsquo;ve found a chocolate egg)</span></span></p>\n<p><span><strong>je voudrais un oeuf en chocolat s&rsquo;il vous pla</strong></span><span><strong>&icirc;</strong></span><span><strong>t</strong></span><span>&nbsp;(I&rsquo;d like a chocolate egg please)&nbsp;</span></p>\n<p><span><strong>le lapin s&rsquo;appelle &hellip;.</strong></span><span>&nbsp;(the rabbit is called&hellip;)&nbsp;</span><span><strong>Joyeuses P&acirc;ques</strong></span><span>&nbsp;(Happy Easter)&nbsp;</span></p>\n<p><br>&nbsp;</p>\n<p><span><strong>Basics</strong></span></p>\n<p><span>Colours &amp; numbers, weather basics</span></p>\n<p><br>&nbsp;</p>\n<p><span><strong>Songs</strong></span><span><span lang=\"fr-FR\"><em>:</em></span></span></p>\n<p><span><span lang=\"fr-FR\">Bonjour Monsieur</span></span></p>\n<p><span><span lang=\"fr-FR\">Dino, as-tu faim?</span></span></p>\n<p><span>Meunier tu dors</span></p>\n<p><span>Le jour de P</span><span>&acirc;</span><span>ques</span></p>','mini-bijou','2024-01-15 15:26:37','2024-01-15 15:26:37');
/*!40000 ALTER TABLE `articles` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cohorts`
--

DROP TABLE IF EXISTS `cohorts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `cohorts` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `slug` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `image` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `order_column` int NOT NULL,
  `active` tinyint(1) NOT NULL DEFAULT '0',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cohorts`
--

LOCK TABLES `cohorts` WRITE;
/*!40000 ALTER TABLE `cohorts` DISABLE KEYS */;
INSERT INTO `cohorts` VALUES (1,'Mini Bijou','mini-bijou',NULL,1,0,'2023-08-31 05:15:57','2023-08-31 05:15:57'),(2,'Petit Bijou','petit-bijou',NULL,2,0,'2023-08-31 05:16:05','2023-08-31 05:16:05');
/*!40000 ALTER TABLE `cohorts` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `courses`
--

DROP TABLE IF EXISTS `courses`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `courses` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `title` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `access_code` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `article_id` bigint unsigned DEFAULT NULL,
  `cohort_id` bigint unsigned DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `courses_article_id_foreign` (`article_id`),
  KEY `courses_cohort_id_foreign` (`cohort_id`),
  CONSTRAINT `courses_article_id_foreign` FOREIGN KEY (`article_id`) REFERENCES `articles` (`id`),
  CONSTRAINT `courses_cohort_id_foreign` FOREIGN KEY (`cohort_id`) REFERENCES `cohorts` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `courses`
--

LOCK TABLES `courses` WRITE;
/*!40000 ALTER TABLE `courses` DISABLE KEYS */;
INSERT INTO `courses` VALUES (1,'2023-08-31 05:16:25','2023-09-10 18:26:15','Petit Summer Term 2023','pomme',NULL,NULL),(2,'2023-08-31 05:16:34','2023-09-10 18:25:49','Mini Summer Term 2023','cerise',NULL,NULL),(3,'2024-01-15 15:11:53','2024-01-15 15:11:53','Petit Bijou Spring 2024','tortue',NULL,2),(4,'2024-01-15 15:27:18','2024-01-15 15:27:18','Mini Bijou Spring 2024','souris',NULL,1),(5,'2024-03-12 08:22:46','2024-03-12 08:22:46','Test Course','pomme',NULL,NULL);
/*!40000 ALTER TABLE `courses` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `failed_jobs`
--

DROP TABLE IF EXISTS `failed_jobs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `failed_jobs` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `uuid` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `connection` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `queue` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `payload` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `exception` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `failed_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `failed_jobs_uuid_unique` (`uuid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `failed_jobs`
--

LOCK TABLES `failed_jobs` WRITE;
/*!40000 ALTER TABLE `failed_jobs` DISABLE KEYS */;
/*!40000 ALTER TABLE `failed_jobs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `migrations`
--

DROP TABLE IF EXISTS `migrations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `migrations` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `migration` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `batch` int NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=17 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `migrations`
--

LOCK TABLES `migrations` WRITE;
/*!40000 ALTER TABLE `migrations` DISABLE KEYS */;
INSERT INTO `migrations` VALUES (1,'2014_10_12_000000_create_users_table',1),(2,'2014_10_12_100000_create_password_reset_tokens_table',1),(3,'2014_10_12_200000_add_two_factor_columns_to_users_table',1),(4,'2019_08_19_000000_create_failed_jobs_table',1),(5,'2019_12_14_000001_create_personal_access_tokens_table',1),(6,'2023_08_25_091324_create_sessions_table',1),(7,'2023_08_25_094121_create_cohorts_table',1),(8,'2023_08_25_094151_create_articles_table',1),(9,'2023_08_25_100733_create_courses_table',1),(10,'2023_08_25_100740_create_activities_table',1),(11,'2023_08_25_100744_create_songs_table',1),(12,'2018_01_01_000000_create_action_events_table',2),(13,'2019_05_10_000000_add_fields_to_action_events_table',2),(14,'2021_08_25_193039_create_nova_notifications_table',2),(15,'2022_04_26_000000_add_fields_to_nova_notifications_table',2),(16,'2022_12_19_000000_create_field_attachments_table',2);
/*!40000 ALTER TABLE `migrations` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `nova_field_attachments`
--

DROP TABLE IF EXISTS `nova_field_attachments`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `nova_field_attachments` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `attachable_type` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `attachable_id` bigint unsigned NOT NULL,
  `attachment` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `disk` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `url` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `nova_field_attachments_attachable_type_attachable_id_index` (`attachable_type`,`attachable_id`),
  KEY `nova_field_attachments_url_index` (`url`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `nova_field_attachments`
--

LOCK TABLES `nova_field_attachments` WRITE;
/*!40000 ALTER TABLE `nova_field_attachments` DISABLE KEYS */;
/*!40000 ALTER TABLE `nova_field_attachments` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `nova_notifications`
--

DROP TABLE IF EXISTS `nova_notifications`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `nova_notifications` (
  `id` char(36) COLLATE utf8mb4_unicode_ci NOT NULL,
  `type` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `notifiable_type` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `notifiable_id` bigint unsigned NOT NULL,
  `data` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `read_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `nova_notifications_notifiable_type_notifiable_id_index` (`notifiable_type`,`notifiable_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `nova_notifications`
--

LOCK TABLES `nova_notifications` WRITE;
/*!40000 ALTER TABLE `nova_notifications` DISABLE KEYS */;
/*!40000 ALTER TABLE `nova_notifications` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `nova_pending_field_attachments`
--

DROP TABLE IF EXISTS `nova_pending_field_attachments`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `nova_pending_field_attachments` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `draft_id` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `attachment` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `disk` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `nova_pending_field_attachments_draft_id_index` (`draft_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `nova_pending_field_attachments`
--

LOCK TABLES `nova_pending_field_attachments` WRITE;
/*!40000 ALTER TABLE `nova_pending_field_attachments` DISABLE KEYS */;
/*!40000 ALTER TABLE `nova_pending_field_attachments` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `password_reset_tokens`
--

DROP TABLE IF EXISTS `password_reset_tokens`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `password_reset_tokens` (
  `email` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`email`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `password_reset_tokens`
--

LOCK TABLES `password_reset_tokens` WRITE;
/*!40000 ALTER TABLE `password_reset_tokens` DISABLE KEYS */;
/*!40000 ALTER TABLE `password_reset_tokens` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `personal_access_tokens`
--

DROP TABLE IF EXISTS `personal_access_tokens`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `personal_access_tokens` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `tokenable_type` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `tokenable_id` bigint unsigned NOT NULL,
  `name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `abilities` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `last_used_at` timestamp NULL DEFAULT NULL,
  `expires_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `personal_access_tokens_token_unique` (`token`),
  KEY `personal_access_tokens_tokenable_type_tokenable_id_index` (`tokenable_type`,`tokenable_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `personal_access_tokens`
--

LOCK TABLES `personal_access_tokens` WRITE;
/*!40000 ALTER TABLE `personal_access_tokens` DISABLE KEYS */;
INSERT INTO `personal_access_tokens` VALUES (1,'App\\Models\\User',1,'web','01d3f85ec80f67ddaa19c42a21d24067f6927cd70ff10730bef8f60f5e64cfe3','[\"*\"]','2023-09-10 18:26:15',NULL,'2023-08-31 05:15:30','2023-09-10 18:26:15'),(2,'App\\Models\\User',1,'insomnia','49a89fc196420c36897eb31a38de368639f7defbcd8dc9d339151a2cddf5d4bf','[\"*\"]','2024-01-23 11:05:58',NULL,'2023-08-31 05:20:56','2024-01-23 11:05:58'),(3,'App\\Models\\User',1,'insomnia','552003e2f258cdb05811acd1f642e7c3b93aa944da6bf69399be5798622c3282','[\"*\"]','2024-01-15 15:00:38',NULL,'2024-01-15 15:00:29','2024-01-15 15:00:38');
/*!40000 ALTER TABLE `personal_access_tokens` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sessions`
--

DROP TABLE IF EXISTS `sessions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `sessions` (
  `id` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `user_id` bigint unsigned DEFAULT NULL,
  `ip_address` varchar(45) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `user_agent` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `payload` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `last_activity` int NOT NULL,
  PRIMARY KEY (`id`),
  KEY `sessions_user_id_index` (`user_id`),
  KEY `sessions_last_activity_index` (`last_activity`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sessions`
--

LOCK TABLES `sessions` WRITE;
/*!40000 ALTER TABLE `sessions` DISABLE KEYS */;
INSERT INTO `sessions` VALUES ('9Eo3RJr0gC0VnqHJHWmrIBPw9aW1vRSxkrtR8m9i',1,'127.0.0.1','Mozilla/5.0 (X11; Linux x86_64; rv:123.0) Gecko/20100101 Firefox/123.0','YTo0OntzOjY6Il90b2tlbiI7czo0MDoibFRDYUFVY2ZGaHRsaE1Jdk1xbThNWE9GcHZMc1loa0V4NzlRaUJ4NyI7czo1MDoibG9naW5fd2ViXzU5YmEzNmFkZGMyYjJmOTQwMTU4MGYwMTRjN2Y1OGVhNGUzMDk4OWQiO2k6MTtzOjY6Il9mbGFzaCI7YToyOntzOjM6Im9sZCI7YTowOnt9czozOiJuZXciO2E6MDp7fX1zOjk6Il9wcmV2aW91cyI7YToxOntzOjM6InVybCI7czo1MDoiaHR0cDovLzEyNy4wLjAuMTo4MDAwL25vdmEvcmVzb3VyY2VzL2FjdGl2aXRpZXMvNDEiO319',1710235844),('KCg3Ang7vDStXbNnVbTWLmbFOgbxavk0GHrAZIvs',NULL,'127.0.0.1','Mozilla/5.0 (X11; Linux x86_64; rv:123.0) Gecko/20100101 Firefox/123.0','YTo0OntzOjY6Il90b2tlbiI7czo0MDoicjJwUW4wc2xqUTJ2cXFHbWliT05hUkd4dm5VNFlTT25MYnpKMThHRCI7czozOiJ1cmwiO2E6MTp7czo4OiJpbnRlbmRlZCI7czo1MDoiaHR0cDovLzEyNy4wLjAuMTo4MDAwL25vdmEvcmVzb3VyY2VzL2FjdGl2aXRpZXMvNDAiO31zOjk6Il9wcmV2aW91cyI7YToxOntzOjM6InVybCI7czo1MDoiaHR0cDovLzEyNy4wLjAuMTo4MDAwL25vdmEvcmVzb3VyY2VzL2FjdGl2aXRpZXMvNDAiO31zOjY6Il9mbGFzaCI7YToyOntzOjM6Im9sZCI7YTowOnt9czozOiJuZXciO2E6MDp7fX19',1710235305),('sGNHr7DuYicYR2fhIpkO5d0h845dzvgLSNxjYGAU',NULL,'127.0.0.1','Mozilla/5.0 (X11; Linux x86_64; rv:123.0) Gecko/20100101 Firefox/123.0','YTozOntzOjY6Il90b2tlbiI7czo0MDoiM29oeW5MekZBTGtHM2VzYldxbXV3YlVZQWNkb1NsQVN5WnJKOGV2RyI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6MzI6Imh0dHA6Ly8xMjcuMC4wLjE6ODAwMC9ub3ZhL2xvZ2luIjt9czo2OiJfZmxhc2giO2E6Mjp7czozOiJvbGQiO2E6MDp7fXM6MzoibmV3IjthOjA6e319fQ==',1710235305);
/*!40000 ALTER TABLE `sessions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `songs`
--

DROP TABLE IF EXISTS `songs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `songs` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `order_column` int NOT NULL,
  `mp3` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `lyrics` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `course_id` bigint unsigned DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `songs_course_id_foreign` (`course_id`),
  CONSTRAINT `songs_course_id_foreign` FOREIGN KEY (`course_id`) REFERENCES `courses` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=17 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `songs`
--

LOCK TABLES `songs` WRITE;
/*!40000 ALTER TABLE `songs` DISABLE KEYS */;
INSERT INTO `songs` VALUES (1,'Bonjour Monsieur',1,'Bonjour_Monsieur_Audio_Mini_Bijou_Summer_2023_76aa6133e8.wav','Bonjour_Monsieur_Song_Lyrics_Mini_Bijou_April_to_July_2023_c11762d347.docx','2023-09-02 09:35:39','2023-09-10 10:21:18',2),(2,'Père Noël',2,'Père Noël Audio_Mini Bijou.mp3','Père Noël Lyrics_Mini Bijou.docx','2023-09-10 10:22:31','2023-09-10 10:23:17',2),(3,'Petit Papa Noël',3,'Petit Papa Noël Audio_Mini Bijou.wav','Petit Papa Noël Lyrics_Mini Bijou.docx','2023-09-10 10:23:23','2023-09-10 10:24:33',2),(4,'Comment Tu T’appelles ?',4,'Comment Tu T\'appelles Audio_Mini Bijou.mp3','Comment Tu T\'appelles Lyrics_Mini Bijou.docx','2023-09-10 10:23:31','2023-09-10 10:24:43',2),(5,'Quel Age As-Tu ?',5,'Quel Age As-Tu Audio_Mini Bijou.mp3','Quel Age As-Tu Song Lyrics_Mini Bijou.docx','2023-09-10 10:23:37','2023-09-10 10:24:53',2),(6,'Bonjour Bonjour comment ça va?',6,'Bonjour Bonjour Comment Ça Va Audio_ Petit Bijou.wav','Bonjour Comment Ça Va Lyrics_Petit Bijou.docx','2023-09-10 10:29:36','2023-09-12 10:05:56',1),(7,'Fais dodo',7,'Fais Dodo Audio_Petit Bijou.mp3','Fais Dodo Lyrics_Petit Bijou.docx','2023-09-10 10:29:43','2023-09-12 10:06:08',1),(8,'Petit Papa Noël',8,'Petit Papa Noël Audio_Petit Bijou.wav','Petit Papa Noël Lyrics_Petit Bijou.docx','2023-09-10 10:29:48','2023-09-12 10:06:21',1),(9,'L’as-Tu Vu ?',9,'L\'as-Tu Vu Audio_Petit Bijou.mp3','L\'as-Tu Vu Lyrics_Petit Bijou.docx','2023-09-10 10:29:55','2023-09-12 10:06:33',1),(10,'Bonjour comment ça va',10,'Bonjour Bonjour Comment Ca Va Audio_Petit Bijou (2).wav','Bonjour Comment Ça Va Lyrics_Petit Bijou.docx','2024-01-15 15:19:12','2024-01-15 15:20:03',3),(11,'Bonjour Monsieur',11,'Bonjour Monsieur Audio - Mini Bijou.wav','Bonjour Monsieur Song Lyrics - Mini Bijou.docx','2024-01-15 15:28:44','2024-01-15 15:29:23',4),(12,'Meunier Tu Dors',12,'Meunier Tu Dors Audio - Mini Bijou.mp3','Meunier Tu Dors Song Lyrics - Mini Bijou.docx','2024-01-18 15:31:24','2024-01-18 15:31:48',4),(13,'Je Joue Au Foot',13,'Je Joue Au Foot audio -Petit Bijou.mp3','Je Joue Au Foot Lyrics_Petit Bijou.docx','2024-01-18 15:34:05','2024-01-18 15:34:29',3),(14,'Dino As-Tu Faim',14,'Dino As-Tu Faim Audio - Mini Bijou.mp3','Dino As-Tu Faim Song Lyrics - Mini Bijou.docx','2024-01-23 10:23:02','2024-01-23 10:23:32',4),(15,'Petit Escargot',15,'Petit Escargot Audio _Petit Bijou.mp3','Petit Escargot Lyrics_Petit Bijou.docx','2024-01-23 10:55:49','2024-01-23 10:56:21',3),(16,'Les Fêtes de Pâques',16,'Les Fêtes de Pâques Audio_Petit Bijou.mp3','','2024-02-20 10:00:00','2024-02-20 10:00:00',3);
/*!40000 ALTER TABLE `songs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `users` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `email_verified_at` timestamp NULL DEFAULT NULL,
  `password` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `two_factor_secret` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `two_factor_recovery_codes` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `two_factor_confirmed_at` timestamp NULL DEFAULT NULL,
  `remember_token` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `current_team_id` bigint unsigned DEFAULT NULL,
  `profile_photo_path` varchar(2048) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `users_email_unique` (`email`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users`
--

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` VALUES (1,'Michael James','michael@notlive.fr',NULL,'$2y$10$2EhPQIwNTIDDFkDE9tbdgu1RJGM7H9oYhpqzw51GHbFNkesRlQW3m',NULL,NULL,NULL,'Kwv0OS0G6eCW85tKjCpy2rL4U203A8df65f1HXX1LjVmskH3wnUctkRVH4EX',NULL,NULL,'2023-08-31 05:15:17','2023-08-31 05:15:17');
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2024-03-12 10:52:42
